function [times] = ejectionTimes(k, dx, M_sat, nRows)
    Fs = k*dx;                          %initial spring force in Newtons
    %PEs = 0.5*k*(dx^2);                %initial spring potential energy in Joules
    M = 1423.9 + (nRows*M_sat*4);       %Initial mass of bay + 500 luna sats in grams
    %R = 70;                            %radius of cylindrical approx, taken from diagnal of lunasat in mm
    %I = 0.5*M*(R^2);                   %initial rotational moment of inertia
    %W = 5;                             %initial rotational speed in RPS
    %L = I*W;                           %initial moment of inertia kg*m^2
    %Fr = M_sat*(W^2)*R;
    times = zeros(1,nRows);
    velocity = zeros(1,nRows);
    %rotSpeed = zeros(1,nRows);
    Mass = zeros(1,nRows);
    Vi = 0;
    totaltime = 0;
    
    
   for i = 1:nRows                          %iterate through every row, times(i) = time
       acc = (k*dx)/(M/1000);               %accelerations in m/s^2
       Vf = sqrt((Vi^2) + 2*acc*0.0017);    %final velocity after 1 displacement
       t = (0.0017*2)/(Vi+Vf);
       totaltime = totaltime + t;
       times(i) = totaltime;
       %velocity(i) = Vf;
       %rotSpeed(i) = W;
       Mass(i) = M;
       M = M - (M_sat*4);                   %New mass after 4 luna sat ejection
       %I = 0.5*M*(R^2);                    %New moment of inertia after mass loss
       %W = L/I;                            %New rotational speed from cons of ang mom
       dx = dx - 1.7;                       %Spring compression - depth of luna sat
       if (dx < 0)
           dx = 0;
       end
       Vi = Vf;
   end
   
   yyaxis left 
   plot(1:125,times)
   ylim([0,2])
   xlim([0,125])
   ylabel('elapsed time (s)')
   xlabel('rows ejected')
   
   yyaxis right
   plot(1:125,Mass)
   ylabel('Mass (g)')
   %velocity
end